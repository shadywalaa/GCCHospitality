import Image from 'next/image'
import { ArrowRight, Utensils, Car, Plane, Gem, Anchor, Sparkles } from 'lucide-react'

const experiences = [
  {
    title: 'Private Dining',
    description: 'World-class chefs crafting bespoke culinary journeys in the privacy of your residence',
    icon: Utensils,
    image: 'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=800&q=80',
  },
  {
    title: 'Luxury Transport',
    description: 'Chauffeur services with premium vehicles and helicopter transfers',
    icon: Car,
    image: 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=800&q=80',
  },
  {
    title: 'Desert Expeditions',
    description: 'Exclusive desert safaris with private camps and traditional Arabian hospitality',
    icon: Sparkles,
    image: 'https://images.unsplash.com/photo-1451337516015-6b6e9a44a8a3?w=800&q=80',
  },
  {
    title: 'Yacht Charters',
    description: 'Private cruises along the Arabian Gulf with dedicated crew',
    icon: Anchor,
    image: 'https://images.unsplash.com/photo-1567899378494-47b22a2ae96a?w=800&q=80',
  },
  {
    title: 'Private Aviation',
    description: 'Seamless jet arrangements for regional and international travel',
    icon: Plane,
    image: 'https://images.unsplash.com/photo-1540962351504-03099e0a754b?w=800&q=80',
  },
  {
    title: 'Bespoke Shopping',
    description: 'Personal stylists and exclusive access to luxury boutiques',
    icon: Gem,
    image: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=800&q=80',
  },
]

export function ExperiencesSection() {
  return (
    <section id="experiences" className="py-24 lg:py-32 bg-card">
      <div className="mx-auto max-w-[1400px] px-6 lg:px-8">
        {/* Header */}
        <div className="max-w-2xl mb-16">
          <div className="flex items-center gap-4 mb-4">
            <div className="h-px w-12 bg-primary" />
            <span className="text-primary text-xs tracking-[0.3em] font-medium">
              CURATED EXPERIENCES
            </span>
          </div>
          <h2 className="text-3xl lg:text-4xl font-light text-foreground mb-4 text-balance">
            Beyond Accommodation
          </h2>
          <p className="text-muted-foreground leading-relaxed">
            Every stay with ALSAFA is an invitation to experience the extraordinary. 
            Our concierge team crafts bespoke moments that transform your journey 
            into an unforgettable narrative.
          </p>
        </div>

        {/* Experiences Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {experiences.map((experience, index) => (
            <div 
              key={experience.title}
              className={`group relative overflow-hidden bg-secondary ${
                index === 0 ? 'md:col-span-2 lg:col-span-1' : ''
              }`}
            >
              <div className="relative h-[280px] overflow-hidden">
                <Image
                  src={experience.image}
                  alt={experience.title}
                  fill
                  className="object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background via-background/50 to-transparent" />
              </div>
              
              <div className="relative p-6 -mt-20">
                <div className="w-12 h-12 bg-primary flex items-center justify-center mb-4">
                  <experience.icon className="w-5 h-5 text-primary-foreground" />
                </div>
                
                <h3 className="text-xl text-foreground font-light mb-2 group-hover:text-primary transition-colors">
                  {experience.title}
                </h3>
                <p className="text-muted-foreground text-sm leading-relaxed mb-4">
                  {experience.description}
                </p>
                
                <button className="flex items-center gap-2 text-primary text-sm group-hover:gap-4 transition-all">
                  Learn More
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
