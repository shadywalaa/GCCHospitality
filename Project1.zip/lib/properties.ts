export interface Property {
  id: string
  name: string
  location: string
  country: string
  type: 'villa' | 'hotel' | 'penthouse' | 'residence'
  price: number
  currency: string
  priceUnit: string
  bedrooms: number
  bathrooms: number
  guests: number
  sqm: number
  rating: number
  reviewCount: number
  images: string[]
  amenities: string[]
  description: string
  shortDescription: string
  featured: boolean
  conciergeServices: string[]
  checkIn: string
  checkOut: string
}

export const properties: Property[] = [
  {
    id: 'pearl-island-villa',
    name: 'Pearl Island Villa',
    location: 'The Pearl-Qatar',
    country: 'Qatar',
    type: 'villa',
    price: 4500,
    currency: 'QAR',
    priceUnit: 'night',
    bedrooms: 6,
    bathrooms: 7,
    guests: 12,
    sqm: 850,
    rating: 4.97,
    reviewCount: 128,
    images: [
      'https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=1200&q=80',
      'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=1200&q=80',
      'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=1200&q=80',
      'https://images.unsplash.com/photo-1600566753086-00f18fb6b3ea?w=1200&q=80',
    ],
    amenities: ['Private Pool', 'Beach Access', 'Home Cinema', 'Chef Kitchen', 'Wine Cellar', 'Gym', 'Spa', 'Smart Home'],
    description: 'Experience the pinnacle of coastal luxury at this magnificent Pearl Island Villa. Nestled on the exclusive waterfront of The Pearl-Qatar, this architectural masterpiece offers 850 square meters of refined living space with breathtaking views of the Arabian Gulf.',
    shortDescription: 'Waterfront masterpiece with private beach access',
    featured: true,
    conciergeServices: ['Private Chef', 'Yacht Charter', 'Chauffeur Service', 'Personal Shopping'],
    checkIn: '15:00',
    checkOut: '11:00',
  },
  {
    id: 'west-bay-penthouse',
    name: 'West Bay Skyline Penthouse',
    location: 'West Bay',
    country: 'Qatar',
    type: 'penthouse',
    price: 6200,
    currency: 'QAR',
    priceUnit: 'night',
    bedrooms: 4,
    bathrooms: 5,
    guests: 8,
    sqm: 620,
    rating: 4.95,
    reviewCount: 89,
    images: [
      'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=1200&q=80',
      'https://images.unsplash.com/photo-1600607687644-aac4c3eac7f4?w=1200&q=80',
      'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?w=1200&q=80',
      'https://images.unsplash.com/photo-1600585154526-990dced4db0d?w=1200&q=80',
    ],
    amenities: ['Rooftop Terrace', 'Private Elevator', 'Floor-to-Ceiling Windows', 'Butler Service', 'Wine Room', 'Home Office'],
    description: 'Commanding the most prestigious address in Doha, this penthouse offers unparalleled 360-degree views of the city skyline and coastline. Floor-to-ceiling windows flood the space with natural light, while curated interiors blend contemporary design with Arabian elegance.',
    shortDescription: '360-degree skyline views from West Bay\'s finest',
    featured: true,
    conciergeServices: ['24/7 Butler', 'Helicopter Transfer', 'Art Curation', 'Event Planning'],
    checkIn: '14:00',
    checkOut: '12:00',
  },
  {
    id: 'desert-oasis-retreat',
    name: 'Desert Oasis Retreat',
    location: 'Inland Sea',
    country: 'Qatar',
    type: 'villa',
    price: 8500,
    currency: 'QAR',
    priceUnit: 'night',
    bedrooms: 8,
    bathrooms: 9,
    guests: 16,
    sqm: 1200,
    rating: 4.99,
    reviewCount: 45,
    images: [
      'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=1200&q=80',
      'https://images.unsplash.com/photo-1600573472592-401b489a3cdc?w=1200&q=80',
      'https://images.unsplash.com/photo-1600566752355-35792bedcfea?w=1200&q=80',
      'https://images.unsplash.com/photo-1600047509807-ba8f99d2cdde?w=1200&q=80',
    ],
    amenities: ['Private Desert', 'Infinity Pool', 'Traditional Majlis', 'Falcon Experience', 'Camel Stable', 'Observatory', 'Spa Pavilion'],
    description: 'A transcendent escape where ancient Arabian heritage meets contemporary luxury. This exclusive desert compound offers an immersive experience with private dunes, traditional Majlis, and world-class amenities under the vast Qatari sky.',
    shortDescription: 'Where Arabian heritage meets modern luxury',
    featured: true,
    conciergeServices: ['Desert Safari', 'Falcon Training', 'Stargazing Guide', 'Bedouin Dining Experience'],
    checkIn: '16:00',
    checkOut: '11:00',
  },
  {
    id: 'lusail-marina-residence',
    name: 'Lusail Marina Residence',
    location: 'Lusail City',
    country: 'Qatar',
    type: 'residence',
    price: 3800,
    currency: 'QAR',
    priceUnit: 'night',
    bedrooms: 5,
    bathrooms: 6,
    guests: 10,
    sqm: 520,
    rating: 4.93,
    reviewCount: 67,
    images: [
      'https://images.unsplash.com/photo-1600047509358-9dc75507daeb?w=1200&q=80',
      'https://images.unsplash.com/photo-1600566753151-384129cf4e3e?w=1200&q=80',
      'https://images.unsplash.com/photo-1600585154526-990dced4db0d?w=1200&q=80',
      'https://images.unsplash.com/photo-1600573472592-401b489a3cdc?w=1200&q=80',
    ],
    amenities: ['Marina View', 'Private Dock', 'Smart Home', 'Gym', 'Steam Room', 'Chef Kitchen', 'Multiple Terraces'],
    description: 'Located in Qatar\'s futuristic Lusail City, this marina residence represents the next chapter of Gulf luxury living. With direct marina access and cutting-edge smart home technology, it offers a lifestyle at the forefront of modern hospitality.',
    shortDescription: 'Future-forward living in Lusail Marina',
    featured: false,
    conciergeServices: ['Yacht Concierge', 'Fitness Trainer', 'Personal Stylist', 'Restaurant Reservations'],
    checkIn: '15:00',
    checkOut: '11:00',
  },
  {
    id: 'katara-cultural-villa',
    name: 'Katara Cultural Villa',
    location: 'Katara Cultural Village',
    country: 'Qatar',
    type: 'villa',
    price: 5200,
    currency: 'QAR',
    priceUnit: 'night',
    bedrooms: 5,
    bathrooms: 6,
    guests: 10,
    sqm: 680,
    rating: 4.96,
    reviewCount: 92,
    images: [
      'https://images.unsplash.com/photo-1600566753086-00f18fb6b3ea?w=1200&q=80',
      'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=1200&q=80',
      'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=1200&q=80',
      'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=1200&q=80',
    ],
    amenities: ['Art Gallery', 'Private Theater', 'Library', 'Courtyard Garden', 'Traditional Hammam', 'Music Room'],
    description: 'Immersed in the heart of Qatar\'s cultural renaissance, this villa offers an artistic sanctuary steps from world-class galleries and performance venues. Arabian architecture meets curated design in this culturally rich retreat.',
    shortDescription: 'Artistic sanctuary in the cultural heart',
    featured: false,
    conciergeServices: ['Gallery Tours', 'Cultural Guide', 'Private Performances', 'Art Acquisition'],
    checkIn: '15:00',
    checkOut: '12:00',
  },
  {
    id: 'dubai-palm-estate',
    name: 'Palm Jumeirah Estate',
    location: 'Palm Jumeirah',
    country: 'UAE',
    type: 'villa',
    price: 12000,
    currency: 'AED',
    priceUnit: 'night',
    bedrooms: 10,
    bathrooms: 12,
    guests: 20,
    sqm: 1800,
    rating: 4.98,
    reviewCount: 156,
    images: [
      'https://images.unsplash.com/photo-1613977257363-707ba9348227?w=1200&q=80',
      'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=1200&q=80',
      'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=1200&q=80',
      'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?w=1200&q=80',
    ],
    amenities: ['Private Beach', 'Infinity Pool', 'Tennis Court', 'Cinema', 'Spa', 'Staff Quarters', 'Helipad'],
    description: 'The ultimate expression of Palm Jumeirah luxury, this estate encompasses nearly 2,000 square meters of impeccable design. From the private beach to the rooftop helipad, every element speaks to an uncompromising standard of excellence.',
    shortDescription: 'The pinnacle of Palm Jumeirah luxury',
    featured: true,
    conciergeServices: ['Helicopter Service', 'Superyacht Charter', 'Personal Security', 'International Chef'],
    checkIn: '14:00',
    checkOut: '12:00',
  },
]

export const propertyTypes = [
  { value: 'all', label: 'All Properties' },
  { value: 'villa', label: 'Villas' },
  { value: 'hotel', label: 'Hotels' },
  { value: 'penthouse', label: 'Penthouses' },
  { value: 'residence', label: 'Residences' },
]

export const locations = [
  { value: 'all', label: 'All Locations' },
  { value: 'qatar', label: 'Qatar' },
  { value: 'uae', label: 'UAE' },
  { value: 'doha', label: 'Doha' },
  { value: 'dubai', label: 'Dubai' },
]
